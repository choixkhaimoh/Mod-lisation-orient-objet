package notreprojet;

import java.util.ArrayList;
import java.util.List;



public class Employe {
  
    private String Nom;

   
    public String getNom() {
        // Automatically generated method. Please do not modify this code.
        return this.Nom;
    }

    
    public void setNom(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.Nom = value;
    }


    private char NumeroEmploye;

  
    public char getNumeroEmploye() {
        // Automatically generated method. Please do not modify this code.
        return this.NumeroEmploye;
    }

   
    public void setNumeroEmploye(final char value) {
        // Automatically generated method. Please do not modify this code.
        this.NumeroEmploye = value;
    }


    public List<Caisse> gere = new ArrayList<Caisse> ();


   // public ClubVideo Travail �;

}
