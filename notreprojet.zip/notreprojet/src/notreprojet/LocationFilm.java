package notreprojet;

public class LocationFilm {

	private String DateLocation;

	public String getDateLocation() {
		// Automatically generated method. Please do not modify this code.
		return this.DateLocation;
	}

	public void setDateLocation(final String value) {
		// Automatically generated method. Please do not modify this code.
		this.DateLocation = value;
	}

	private int NumeroClient;

	public int getNumeroClient() {
		// Automatically generated method. Please do not modify this code.
		return this.NumeroClient;
	}

	public void setNumeroClient(final int value) {
		// Automatically generated method. Please do not modify this code.
		this.NumeroClient = value;
	}

	private char CodeFilm;

	public char getCodeFilm() {
		// Automatically generated method. Please do not modify this code.
		return this.CodeFilm;
	}

	public void setCodeFilm(final char value) {
		// Automatically generated method. Please do not modify this code.
		this.CodeFilm = value;
	}

	private int NbrFilm;

	public int getNbrFilm() {
		// Automatically generated method. Please do not modify this code.
		return this.NbrFilm;
	}

	public void setNbrFilm(final int value) {
		// Automatically generated method. Please do not modify this code.
		this.NbrFilm = value;
	}

}