package notreprojet;

import java.util.Date;



public class Facture {
    
    private int numeroFacture;

   
    public int getNumeroFacture() {
        // Automatically generated method. Please do not modify this code.
        return this.numeroFacture;
    }

    
    public void setNumeroFacture(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.numeroFacture = value;
    }


    
    private int Montant;


    public int getMontant() {
        // Automatically generated method. Please do not modify this code.
        return this.Montant;
    }

   
    public void setMontant(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.Montant = value;
    }

   
  
    private Date DateLocation;

   
    public Date getDateLocation() {
        // Automatically generated method. Please do not modify this code.
        return this.DateLocation;
    }

   
    public void setDateLocation(final Date value) {
        // Automatically generated method. Please do not modify this code.
        this.DateLocation = value;
    }

}
