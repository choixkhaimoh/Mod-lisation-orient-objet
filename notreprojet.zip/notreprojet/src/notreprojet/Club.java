package notreprojet;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPasswordField;
import javax.swing.JSpinner;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import javax.swing.UIManager;

public class Club {

	private JFrame frame;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Club window = new Club();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Club() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setForeground(Color.BLACK);
		frame.getContentPane().setBackground(Color.GRAY);
		frame.setBackground(Color.GRAY);
		frame.setBounds(100, 100, 450, 550);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JButton btnNewButton = new JButton("Se connecter");
		btnNewButton.setBounds(47, 397, 129, 28);
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		frame.getContentPane().add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				MainGUI.setVisible(true);
			}

		}

		);

		JPanel panel = new JPanel();
		panel.setBounds(140, 23, 152, 100);
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 0, 152, 100);
		panel.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblNewLabel = new JLabel("     VIDEO CLUB");
		lblNewLabel.setBounds(0, 0, 152, 100);
		panel_1.add(lblNewLabel);
		lblNewLabel.setLabelFor(frame);
		lblNewLabel.setForeground(Color.DARK_GRAY);
		lblNewLabel.setFont(new Font("Californian FB", Font.BOLD, 16));
		lblNewLabel.setBackground(Color.LIGHT_GRAY);

		JLabel lblNewLabel_4 = new JLabel("FILMS");
		lblNewLabel_4.setFont(new Font("Californian FB", Font.BOLD, 16));
		lblNewLabel_4.setBounds(38, 60, 68, 19);
		panel_1.add(lblNewLabel_4);

		JPanel panel_2 = new JPanel();
		panel_2.setBounds(125, 317, 200, 41);
		panel_2.setBorder(UIManager.getBorder("PasswordField.border"));
		frame.getContentPane().add(panel_2);
		panel_2.setLayout(null);

		passwordField = new JPasswordField();
		passwordField.setBounds(0, 0, 200, 41);
		panel_2.add(passwordField);
		passwordField.setForeground(Color.LIGHT_GRAY);
		passwordField.setToolTipText("");
		passwordField.setFont(new Font("Tahoma", Font.PLAIN, 10));

		JLabel lblNewLabel_1 = new JLabel("Mot de passe:");
		lblNewLabel_1.setBounds(125, 286, 112, 21);
		lblNewLabel_1.setBackground(new Color(240, 240, 240));
		lblNewLabel_1.setFont(new Font("Californian FB", Font.BOLD, 15));
		frame.getContentPane().add(lblNewLabel_1);

		JTextPane textPane = new JTextPane();
		textPane.setBounds(126, 225, 200, 41);
		textPane.setFont(new Font("Californian FB", Font.BOLD, 15));
		textPane.setBackground(Color.WHITE);
		frame.getContentPane().add(textPane);

		JLabel lblNewLabel_2 = new JLabel("Identification");
		lblNewLabel_2.setBounds(126, 187, 85, 21);
		lblNewLabel_2.setFont(new Font("Californian FB", Font.BOLD, 15));
		frame.getContentPane().add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("ou devenir");
		lblNewLabel_3.setBounds(201, 402, 65, 21);
		lblNewLabel_3.setFont(new Font("Californian FB", Font.BOLD, 15));
		frame.getContentPane().add(lblNewLabel_3);

		JButton btnNewButton_1 = new JButton("membre");
		btnNewButton_1.setBounds(276, 397, 85, 28);
		btnNewButton_1.setBackground(Color.LIGHT_GRAY);
		frame.getContentPane().add(btnNewButton_1);
	}
}
