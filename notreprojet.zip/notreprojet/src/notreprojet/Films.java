package notreprojet;
import java.util.Date;


public class Films {
   
    private char CodeFilm;

 
    public char getCodeFilm() {
        // Automatically generated method. Please do not modify this code.
        return this.CodeFilm;
    }

  
    public void setCodeFilm(final char value) {
        // Automatically generated method. Please do not modify this code.
        this.CodeFilm = value;
    }

    private Date DateSortie;


    public Date getDateSortie() {
        // Automatically generated method. Please do not modify this code.
        return this.DateSortie;
    }


    public void setDateSortie(final Date value) {
        // Automatically generated method. Please do not modify this code.
        this.DateSortie = value;
    }

  
    private String StatutFilm;

   
    public String getStatutFilm() {
        // Automatically generated method. Please do not modify this code.
        return this.StatutFilm;
    }

    
    public void setStatutFilm(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.StatutFilm = value;
    }

    
    //  public DescriptionFilm Decrit par;

   
   // public locationFilm ;

}