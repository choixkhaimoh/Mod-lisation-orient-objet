package notreprojet;

@objid ("9db33b31-0f88-4da1-a638-1df7ca53a5d8")
public class ClubVideo {
    
    @objid ("e604daef-dbed-45f6-8cf2-382ea945d1c1")
    private String Nom;

    @mdl.propgetter
    public String getNom() {
        // Automatically generated method. Please do not modify this code.
        return this.Nom;
    }

    @mdl.propsetter
    public void setNom(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.Nom = value;
    }

}
