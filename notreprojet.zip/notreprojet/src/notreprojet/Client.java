package notreprojet;

import java.util.ArrayList;
import java.util.List;

public class Client {

	private int NumeroClient;

	public int getNumeroClient() {
		// Automatically generated method. Please do not modify this code.
		return this.NumeroClient;
	}

	public void setNumeroClient(final int value) {
		// Automatically generated method. Please do not modify this code.
		this.NumeroClient = value;
	}

	private String Nom;

	public String getNom() {
		// Automatically generated method. Please do not modify this code.
		return this.Nom;
	}

	public void setNom(final String value) {
		// Automatically generated method. Please do not modify this code.
		this.Nom = value;
	}

	private char Telephone;

	public char getTelephone() {
		// Automatically generated method. Please do not modify this code.
		return this.Telephone;
	}

	public void setTelephone(final char value) {
		// Automatically generated method. Please do not modify this code.
		this.Telephone = value;
	}

	public List<locationFilm> Effectuer = new ArrayList<locationFilm>();

	public List<Caisse> C = new ArrayList<Caisse>();

}
