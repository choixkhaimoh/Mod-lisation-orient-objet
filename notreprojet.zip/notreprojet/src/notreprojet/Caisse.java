package notreprojet;

public class Caisse {
    
    private String NumeroCaisse;

    
    public String getNumeroCaisse() {
        // Automatically generated method. Please do not modify this code.
        return this.NumeroCaisse;
    }

  
    public void setNumeroCaisse(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.NumeroCaisse = value;
    }

  
    //public Facture ;

}
