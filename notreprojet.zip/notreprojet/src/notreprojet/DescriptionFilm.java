package notreprojet;

import java.util.Date;

public class DescriptionFilm {
	private String titre;
	private Date duree;
	private String categorie;
	private double Prix;
	private int Nbrcopie;

}
